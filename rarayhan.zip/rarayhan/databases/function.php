<?php
// Koneksi Database
$koneksi = mysqli_connect("localhost", "root", "", "db_rayhan");

// Cek koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Fungsi query untuk mengambil data (hasil berupa array)
function query($query)
{
    global $koneksi;

    $result = mysqli_query($koneksi, $query,);

    $rows = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }

    return $rows;
}

// Fungsi tambah data
function tambah($data)
{
    global $koneksi;

    // Escape data untuk mencegah XSS dan SQL Injection
    $nisn = htmlspecialchars(mysqli_real_escape_string($koneksi, $data["nisn"] ?? ''));
    $nama = htmlspecialchars(mysqli_real_escape_string($koneksi, $data["nama"] ?? ''));
    $kelas = htmlspecialchars(mysqli_real_escape_string($koneksi, $data["kelas"] ?? ''));
    $gender = htmlspecialchars(mysqli_real_escape_string($koneksi, $data["gender"] ?? ''));
    $alamat = htmlspecialchars(mysqli_real_escape_string($koneksi, $data["alamat"] ?? ''));

    $query = "INSERT INTO tb_ray (nisn, nama, kelas, gender, alamat)
              VALUES ('$nisn', '$nama', '$kelas', '$gender', '$alamat')";

    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        echo "Error tambah data: " . mysqli_error($koneksi);
    }

    return $result;
}

// Fungsi hapus data
function hapus($nisn)
{
    global $koneksi;

    // Escape $nisn dan tambah tanda kutip agar aman (nisn diasumsikan string)
    $nisn = mysqli_real_escape_string($koneksi, $nisn);

    $query = "DELETE FROM tb_ray WHERE nisn = '$nisn'";

    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        echo "Error hapus data: " . mysqli_error($koneksi);
        return 0;
    }

    return mysqli_affected_rows($koneksi);
}

// Fungsi ubah data (harus ada nisn_lama)
function ubah($data)
{
    global $koneksi;

    $nisn_lama = mysqli_real_escape_string($koneksi, $data["nisn_lama"] ?? '');
    $nisn_baru = mysqli_real_escape_string($koneksi, $data["nisn"] ?? '');
    $nama = mysqli_real_escape_string($koneksi, $data["nama"] ?? '');
    $kelas = mysqli_real_escape_string($koneksi, $data["kelas"] ?? '');
    $gender = mysqli_real_escape_string($koneksi, $data["gender"] ?? '');
    $alamat = mysqli_real_escape_string($koneksi, $data["alamat"] ?? '');

    $query = "UPDATE tb_ray SET 
                nisn = '$nisn_baru', 
                nama = '$nama', 
                kelas = '$kelas', 
                gender = '$gender',
                alamat = '$alamat' 
              WHERE nisn = '$nisn_lama'";

    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        echo "Error ubah data: " . mysqli_error($koneksi);
    }

    return mysqli_affected_rows($koneksi);
}
?>
