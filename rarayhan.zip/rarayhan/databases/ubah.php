<?php
require 'function.php';

$nisn = $_GET['nisn'];
$siswa = query("SELECT * FROM tb_ray WHERE nisn = '$nisn'")[0];

if (isset($_POST['ubah'])) {
    $nisn_lama = $_POST['nisn_lama'];
    if (ubah($_POST, $nisn_lama) > 0) {
        echo "<script>
                alert('Data siswa berhasil diubah!');
                document.location.href = 'index.php';
              </script>";
    } else {
        echo "<script>
                alert('Data siswa gagal diubah!');
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Ubah Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" />
    <link href="https://fonts.googleapis.com/css2?family=Righteous&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="container">
    <div class="row my-2">
        <div class="col-md">
            <h3 class="fw-bold text-uppercase">
                <i class="bi bi-pencil-square"></i>&nbsp;Ubah Data Siswa
            </h3>
        </div>
        <hr />
    </div>
    <div class="row my-2">
        <div class="col-md">
            <form action="" method="post">
                <!-- Hidden input untuk nisn lama -->
                <input type="hidden" name="nisn_lama" value="<?= htmlspecialchars($siswa['nisn']); ?>" />

                <div class="mb-3">
                    <label for="nisn" class="form-label">NISN</label>
                    <input
                        type="text"
                        class="form-control w-50"
                        id="nisn"
                        name="nisn"
                        value="<?= htmlspecialchars($siswa['nisn']); ?>"
                        required
                    />
                </div>
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama</label>
                    <input
                        type="text"
                        class="form-control w-50"
                        id="nama"
                        name="nama"
                        value="<?= htmlspecialchars($siswa['nama']); ?>"
                        autocomplete="off"
                        required
                    />
                </div>
                <div class="mb-3">
                    <label for="kelas" class="form-label">Kelas</label>
                    <input
                        type="text"
                        class="form-control w-50"
                        id="kelas"
                        name="kelas"
                        value="<?= htmlspecialchars($siswa['kelas']); ?>"
                        autocomplete="off"
                        required
                    />
                </div>
                <div class="mb-3">
                    <label for="gender" class="form-label">Gender</label>
                    <input
                        type="text"
                        class="form-control w-50"
                        id="gender"
                        name="gender"
                        value="<?= htmlspecialchars($siswa['gender']); ?>"
                        autocomplete="off"
                        required
                    />
                </div>
                <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <input
                        type="text"
                        class="form-control w-50"
                        id="alamat"
                        name="alamat"
                        value="<?= htmlspecialchars($siswa['alamat']); ?>"
                        autocomplete="off"
                        required
                    />
                </div>
                <hr />
                <a href="index.php" class="btn btn-secondary">Kembali</a>
                <button type="submit" class="btn btn-warning" name="ubah">Ubah</button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
