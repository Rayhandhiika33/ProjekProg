<?php
// Aktifkan error reporting untuk debugging (bisa dimatikan kalau sudah stabil)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Hubungkan ke file function.php yang sudah berisi koneksi dan fungsi hapus
require 'function.php';

// Cek apakah parameter 'nisn' ada dan tidak kosong
if (!isset($_GET['nisn']) || trim($_GET['nisn']) === '') {
    echo "<script>
            alert('Data tidak valid!');
            window.location.href = 'index.php';
          </script>";
    exit;
}

// Ambil dan bersihkan NISN dari URL
$nisn = trim($_GET['nisn']);

// Panggil fungsi hapus, cek apakah berhasil
if (hapus($nisn) > 0) {
    echo "<script>
            alert('Data Siswa berhasil dihapus!');
            window.location.href = 'index.php';
          </script>";
} else {
    echo "<script>
            alert('Data Siswa gagal dihapus!');
            window.location.href = 'index.php';
          </script>";
}
