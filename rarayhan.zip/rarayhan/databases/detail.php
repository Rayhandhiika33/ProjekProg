<?php
require 'function.php'; // pastikan koneksi $koneksi tersedia

if (isset($_POST['dataSiswa'])) {
    $nisn = mysqli_real_escape_string($koneksi, $_POST['dataSiswa']);
    $sql = "SELECT * FROM tb_ray WHERE nisn = '$nisn'";
    $result = mysqli_query($koneksi, $sql);

    $output = '<div class="table-responsive"><table class="table table-bordered">';

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $output .= '
                <tr><th width="40%">NISN</th><td width="60%">' . htmlspecialchars($row['nisn']) . '</td></tr>
                <tr><th width="40%">Nama</th><td width="60%">' . htmlspecialchars($row['nama']) . '</td></tr>
                <tr><th width="40%">Kelas</th><td width="60%">' . htmlspecialchars($row['kelas']) . '</td></tr>
                <tr><th width="40%">Gender</th><td width="60%">' . htmlspecialchars($row['gender']) . '</td></tr>
                <tr><th width="40%">Alamat</th><td width="60%">' . htmlspecialchars($row['alamat']) . '</td></tr>
            ';
        }
    } else {
        $output .= '<tr><td colspan="2">Data tidak ditemukan.</td></tr>';
    }

    $output .= '</table></div>';

    echo $output;
}
?>
